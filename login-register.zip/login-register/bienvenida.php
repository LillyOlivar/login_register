<?php
session_start();
// Verificar si NO existe la sesión del usuario
if (!isset($_SESSION['usuario'])) {
    echo '
    <script>
    alert("Por favor debes iniciar sesión");
    window.location="index.php";
    </script>
    ';                 
    session_destroy(); 
    die();                                                                 
}

include 'assets/php/conexion_be.php';

// Obtener los datos más recientes del sensor
function getLatestSensorData($conexion) {
    $sql = "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1";
    $result = $conexion->query($sql);
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

$sensorData = getLatestSensorData($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenida - Estación Meteorológica</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .user-panel {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        .user-panel h1 {
            color: #46A2FD;
        }
        .user-panel nav {
            margin: 20px 0;
        }
        .user-panel nav ul {
            list-style-type: none;
            padding: 0;
        }
        .user-panel nav ul li {
            display: inline-block;
            margin-right: 10px;
        }
        .user-panel button {
            background-color: #46A2FD;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .user-panel button:hover {
            background-color: #3483fa;
        }
        .sensor-data {
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        .sensor-data h2 {
            color: #46A2FD;
        }
        #sensorData canvas {
            max-width: 100%;
            margin: 20px auto;
            display: block;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #ffffff;
        }
        .alert {
            background-color: #ffe0e0;
            border-left: 4px solid #ff4444;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }
        .alert p {
            margin: 5px 0;
        }
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <main>
        <div class="user-panel">
            <h1>Bienvenido a la Estación Meteorológica</h1>
            <p>Hola, <?php echo $_SESSION['usuario']; ?>, ¡bienvenido a tu panel de usuario!</p>
            
            <nav>
                <ul>
                    <li><button onclick="verNotificaciones()"><i class="fas fa-bell"></i> Ver Notificaciones</button></li>
                    <li><button onclick="estadoSensores()"><i class="fas fa-thermometer-half"></i> Estado de Sensores</button></li>
                    <li><button onclick="editarPerfil()"><i class="fas fa-user-edit"></i> Editar Perfil</button></li>
                </ul>
            </nav>

            <section id="contenidoDinamico">
                <!-- Aquí se cargará el contenido dinámicamente -->
            </section>
            <section class="sensor-data">
                <h2>Datos de los Sensores</h2>
                <?php if ($sensorData): ?>
                    <p>Temperatura: <?php echo $sensorData['temperature']; ?> °C</p>
                    <p>Humedad: <?php echo $sensorData['humidity']; ?> %</p>
                    <p>Intensidad UV: <?php echo $sensorData['uvIntensity']; ?> mW/cm²</p>
                    <p>PM2.5: <?php echo $sensorData['pm25']; ?> µg/m³</p>
                    <p>PM10: <?php echo $sensorData['pm10']; ?> µg/m³</p>
                    <p>Última actualización: <?php echo $sensorData['timestamp']; ?></p>
                <?php else: ?>
                    <p>No hay datos de sensores disponibles.</p>
                <?php endif; ?>
            </section>

            <section id="sensorData" class="sensor-data">
                <h2>Gráficos de Datos de Sensores</h2>
                <!--<canvas id="tempChart" width="400" height="200"></canvas>
                <canvas id="humidityChart" width="400" height="200"></canvas>
                <canvas id="uvChart" width="400" height="200"></canvas>-->
                <div class="chart-container">
                    <canvas id="tempChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="humidityChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="uvChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="pmChart"></canvas>
                </div>
            </section>
        </div>
    </main>

    <a href="assets/php/cerrar_sesion.php" class="cerrar-sesion"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>

    <script>
        // Definición de umbrales
        const THRESHOLDS = {
        temperature: { max: 30, min: 10 },
        humidity: { max: 80, min: 20 },
        uvIntensity: { max: 8 },
        pm25: { max: 35 },
        pm10: { max: 50 }
    };
    // Configuración común para los gráficos
    const commonChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            },
            x: {
                grid: {
                    display: false
                }
            }
        },
        plugins: {
            legend: {
                position: 'top'
            }
        },
        animation: {
            duration: 750
        }
    };
       /* function verNotificaciones() {
            document.getElementById('contenidoDinamico').innerHTML = '<h2>Notificaciones</h2><p>No tienes nuevas notificaciones.</p>';
        }*/ 

       // Funciones del panel de usuario
    function verNotificaciones() {
        fetch('assets/php/get_alerts.php')
            .then(response => response.json())
            .then(data => {
                let html = '<h2>Notificaciones</h2>';
                if (data.length > 0) {
                    data.forEach(alert => {
                        html += `
                            <div class="alert">
                                <p><strong>${alert.fecha}</strong></p>
                                <p>${alert.mensaje}</p>
                            </div>
                        `;
                    });
                } else {
                    html += '<p>No hay notificaciones.</p>';
                }
                document.getElementById('contenidoDinamico').innerHTML = html;
            })
            .catch(error => console.error('Error al cargar notificaciones:', error));
    }

       
    function estadoSensores() {
        fetch('assets/php/check_thresholds.php')
            .then(response => response.json())
            .then(data => {
                let html = '<h2>Estado de Sensores</h2>';
                if (data.sensorData) {
                    const status = data.hasAlerts ? 'Alerta' : 'Normal';
                    const statusColor = data.hasAlerts ? '#ff4444' : '#44ff44';
                    
                    html += `
                        <div style="padding: 15px; background-color: ${statusColor}20; border-radius: 5px; margin-bottom: 15px;">
                            <h3 style="color: ${statusColor}">Estado General: ${status}</h3>
                            <p><strong>Última lectura:</strong> ${data.sensorData.timestamp}</p>
                        </div>
                        <div class="sensor-readings">
                            <div class="sensor-reading ${data.sensorData.temperature > THRESHOLDS.temperature.max || data.sensorData.temperature < THRESHOLDS.temperature.min ? 'alert' : ''}">
                                <h4>Temperatura</h4>
                                <p>${data.sensorData.temperature}°C</p>
                                <small>Límites: ${THRESHOLDS.temperature.min}°C - ${THRESHOLDS.temperature.max}°C</small>
                            </div>
                            <div class="sensor-reading ${data.sensorData.humidity > THRESHOLDS.humidity.max || data.sensorData.humidity < THRESHOLDS.humidity.min ? 'alert' : ''}">
                                <h4>Humedad</h4>
                                <p>${data.sensorData.humidity}%</p>
                                <small>Límites: ${THRESHOLDS.humidity.min}% - ${THRESHOLDS.humidity.max}%</small>
                            </div>
                            <div class="sensor-reading ${data.sensorData.uvIntensity > THRESHOLDS.uvIntensity.max ? 'alert' : ''}">
                                <h4>UV</h4>
                                <p>${data.sensorData.uvIntensity} mW/cm²</p>
                                <small>Límite máximo: ${THRESHOLDS.uvIntensity.max} mW/cm²</small>
                            </div>
                            <div class="sensor-reading ${data.sensorData.pm25 > THRESHOLDS.pm25.max ? 'alert' : ''}">
                                <h4>PM2.5</h4>
                                <p>${data.sensorData.pm25} µg/m³</p>
                                <small>Límite máximo: ${THRESHOLDS.pm25.max} µg/m³</small>
                            </div>
                            <div class="sensor-reading ${data.sensorData.pm10 > THRESHOLDS.pm10.max ? 'alert' : ''}">
                                <h4>PM10</h4>
                                <p>${data.sensorData.pm10} µg/m³</p>
                                <small>Límite máximo: ${THRESHOLDS.pm10.max} µg/m³</small>
                            </div>
                        </div>
                    `;
                } else {
                    html += '<p>Error al obtener el estado de los sensores.</p>';
                }
                document.getElementById('contenidoDinamico').innerHTML = html;
            })
            .catch(error => console.error('Error:', error));
    }

         function editarPerfil() {
            // Ocultar gráficos de sensores
            document.getElementById('sensorData').style.display = 'none';

            // Cargar datos del usuario desde la sesión
            let nombreCompleto = "<?php echo isset($_SESSION['nombre_completo']) ? htmlspecialchars($_SESSION['nombre_completo']) : ''; ?>";
            let correo = "<?php echo isset($_SESSION['correo']) ? htmlspecialchars($_SESSION['correo']) : ''; ?>";
            let usuario = "<?php echo isset($_SESSION['usuario']) ? htmlspecialchars($_SESSION['usuario']) : ''; ?>";
            let pais = "<?php echo isset($_SESSION['pais']) ? htmlspecialchars($_SESSION['pais']) : ''; ?>";

            document.getElementById('contenidoDinamico').innerHTML = `
                <h2>Editar Perfil</h2>
                <div id="mensaje-actualizacion"></div>
                <form id="editarPerfilForm">
                    <div class="form-group">
                        <label for="nombre">Nombre completo:</label>
                        <input type="text" id="nombre" name="nombre_completo" value="${nombreCompleto}" required>
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo electrónico:</label>
                        <input type="email" id="correo" name="correo" value="${correo}" required>
                    </div>
                    <div class="form-group">
                        <label for="usuario">Usuario:</label>
                        <input type="text" id="usuario" name="usuario" value="${usuario}" required>
                    </div>
                    <div class="form-group">
                        <label for="contrasena">Nueva contraseña (dejar en blanco para mantener la actual):</label>
                        <input type="password" id="contrasena" name="contrasena">
                    </div>
                    <div class="form-group">
                        <label for="pais">País:</label>
                        <input type="text" id="pais" name="pais" value="${pais}" required>
                    </div>
                    <button type="submit">Actualizar Perfil</button>
                </form>
            `;

            // Agregar event listener para el formulario
            document.getElementById('editarPerfilForm').addEventListener('submit', function(e) {
                e.preventDefault();
                actualizarPerfil();
            });
        }

      function actualizarPerfil() {
    const form = document.getElementById('editarPerfilForm');
    const formData = new FormData(form);
    const mensajeDiv = document.getElementById('mensaje-actualizacion');

    fetch('assets/php/actualizar_perfil.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Clear form fields
            form.reset();

            // Mostrar mensaje de éxito
            mensajeDiv.innerHTML = data.message;
            mensajeDiv.className = 'success';
            
            // Redirigir después de un breve momento
            setTimeout(() => {
                window.location.href = data.redirect;
            }, 2000);
        } else {
            // Mostrar mensaje de error
            mensajeDiv.innerHTML = data.message;
            mensajeDiv.className = 'error';
        }
    })
   
}
        if (Notification.permission !== 'granted') {
            Notification.requestPermission();
        }

       
    // Función para verificar umbrales
    function checkSensorThresholds(data) {
    const alerts = [];

    if (data.temperature > THRESHOLDS.temperature.max) {
        alerts.push(`¡Temperatura alta! ${data.temperature}°C (máx: ${THRESHOLDS.temperature.max}°C)`);
    } else if (data.temperature < THRESHOLDS.temperature.min) {
        alerts.push(`¡Temperatura baja! ${data.temperature}°C (mín: ${THRESHOLDS.temperature.min}°C)`);
    }

    if (data.humidity > THRESHOLDS.humidity.max) {
        alerts.push(`¡Humedad alta! ${data.humidity}% (máx: ${THRESHOLDS.humidity.max}%)`);
    } else if (data.humidity < THRESHOLDS.humidity.min) {
        alerts.push(`¡Humedad baja! ${data.humidity}% (mín: ${THRESHOLDS.humidity.min}%)`);
    }

    if (data.uvIntensity > THRESHOLDS.uvIntensity.max) {
        alerts.push(`¡Índice UV alto! ${data.uvIntensity} (máx: ${THRESHOLDS.uvIntensity.max})`);
    }

    if (data.pm25 > THRESHOLDS.pm25.max) {
        alerts.push(`¡Nivel PM2.5 alto! ${data.pm25} µg/m³ (máx: ${THRESHOLDS.pm25.max})`);
    }

    if (data.pm10 > THRESHOLDS.pm10.max) {
        alerts.push(`¡Nivel PM10 alto! ${data.pm10} µg/m³ (máx: ${THRESHOLDS.pm10.max})`);
    }

    // Mostrar alertas en notificación o ventana emergente
    if (alerts.length > 0) {
        alerts.forEach(alert => {
            showPopup(alert);  // Mostrar alerta en una ventana emergente
            showNotification(alert);  // Mostrar alerta en notificación del navegador
        });
    }
}

        // Mostrar notificación del navegador
        function showNotification(message) {
    if (Notification.permission === 'granted') {
        new Notification('Alerta de Sensor', {
            body: message,
            icon: 'assets/images/notificacion.png'
        });
    }
}

function showPopup(message) {
    alert(`¡Alerta!\n${message}`);
}

// hasta aqui para copiarla 

        // Inicializar gráficos
        function initCharts() {
            window.tempChart = new Chart(document.getElementById('tempChart'), {
                type: 'line',
                data: { labels: [], datasets: [{ label: 'Temperatura (°C)', data: [], borderColor: 'rgb(255, 99, 132)', fill: false }] }
            });

            window.humidityChart = new Chart(document.getElementById('humidityChart'), {
                type: 'line',
                data: { labels: [], datasets: [{ label: 'Humedad (%)', data: [], borderColor: 'rgb(54, 162, 235)', fill: false }] }
            });

            window.uvChart = new Chart(document.getElementById('uvChart'), {
                type: 'line',
                data: { labels: [], datasets: [{ label: 'Intensidad UV (mW/cm²)', data: [], borderColor: 'rgb(255, 206, 86)', fill: false }] }
            });
              
            window.pmChart = new Chart(document.getElementById('pmChart'), {
            type: 'line',
            data: { 
            labels: [], 
            datasets: [
            { label: 'PM2.5 (µg/m³)', data: [], borderColor: 'rgb(75, 192, 192)', fill: false },
            { label: 'PM10 (µg/m³)', data: [], borderColor: 'rgb(153, 102, 255)', fill: false }
        ]
    }
});


        }

        initCharts(); // Llamar para inicializar los gráficos

        function updateSensorData() {
    fetch('assets/php/get_sensor_data.php')
        .then(response => response.json())
        .then(data => {
            if (!data || data.timestamp === null) {
                console.error("No se obtuvieron datos válidos del sensor.");
                return;
            }
            checkSensorThresholds(data); // Verificar umbrales y mostrar alertas

            const currentTime = new Date().toLocaleTimeString();

            // Actualizar gráfico de temperatura
            window.tempChart.data.labels.push(currentTime);
            window.tempChart.data.datasets[0].data.push(data.temperature);
            if (window.tempChart.data.labels.length > 10) {
                window.tempChart.data.labels.shift();
                window.tempChart.data.datasets[0].data.shift();
            }
            window.tempChart.update();

            // Actualizar gráfico de humedad
            window.humidityChart.data.labels.push(currentTime);
            window.humidityChart.data.datasets[0].data.push(data.humidity);
            if (window.humidityChart.data.labels.length > 10) {
                window.humidityChart.data.labels.shift();
                window.humidityChart.data.datasets[0].data.shift();
            }
            window.humidityChart.update();

            // Actualizar gráfico de UV
            window.uvChart.data.labels.push(currentTime);
            window.uvChart.data.datasets[0].data.push(data.uvIntensity);
            if (window.uvChart.data.labels.length > 10) {
                window.uvChart.data.labels.shift();
                window.uvChart.data.datasets[0].data.shift();
            }
            window.uvChart.update();

            // Actualizar gráfico de PM (PM2.5 y PM10)
            window.pmChart.data.labels.push(currentTime);
            window.pmChart.data.datasets[0].data.push(data.pm25);
            window.pmChart.data.datasets[1].data.push(data.pm10);
            if (window.pmChart.data.labels.length > 10) {
                window.pmChart.data.labels.shift();
                window.pmChart.data.datasets[0].data.shift();
                window.pmChart.data.datasets[1].data.shift();
            }
            window.pmChart.update();
        })
        .catch(error => console.error('Error al obtener los datos del sensor:', error));
}
function verNotificaciones(data) {
    let mensaje = '<h2>Notificaciones</h2>';
    if (data && (data.temperature > temperatureThreshold || data.humidity > humidityThreshold)) {
        mensaje += `<div class="alert">
            <p>¡Alerta! - ${new Date().toLocaleTimeString()}</p>
            <p>Temperatura: ${data.temperature}°C</p>
            <p>Humedad: ${data.humidity}%</p>
        </div>`;
    } else {
        mensaje += '<p>No tienes nuevas notificaciones.</p>';
    }
    document.getElementById('contenidoDinamico').innerHTML = mensaje;
}

        // Modificar la función verNotificaciones para mostrar alertas actuales

updateSensorData();

setInterval(updateSensorData, 5000);
    </script>
</body>
</html>