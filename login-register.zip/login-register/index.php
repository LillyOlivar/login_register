<?php
session_start();

if(isset($_SESSION['usuario'])){

    if($_SESSION['rol'] == 'admin') {
        header("location: admin_bienvenida.php");
    } else {
        header("location: bienvenida.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login y Register - MagtimusPro</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <style>
        .contenedor__admin-login {
            position: fixed;
            bottom: 20px;
            left: 20px;
            background-color: rgba(255, 255, 255, 0.5);
            padding: 10px;
            border-radius: 5px;
            transition: all 0.3s ease;
        }

        .contenedor__admin-login:hover {
            background-color: rgba(255, 255, 255, 0.8);
        }

        .formulario__admin-login {
            display: flex;
            flex-direction: column;
        }

        .formulario__admin-login h2 {
            font-size: 14px;
            margin-bottom: 5px;
            color: #46A2FD;
        }

        .formulario__admin-login input {
            margin-bottom: 5px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 3px;
            font-size: 12px;
        }

        .formulario__admin-login button {
            background-color: #46A2FD;
            color: white;
            border: none;
            padding: 5px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 12px;
        }

        .formulario__admin-login button:hover {
            background-color: #3483fa;
        }
    </style>
</head>
<body>
    <main>
        <div class="contenedor__todo">
            <div class="caja__trasera">
                <div class="caja__trasera-login">
                    <h3>¿Ya tienes una cuenta?</h3>
                    <p>Inicia sesión para entrar en la página</p>
                    <button id="btn__iniciar-sesion">Iniciar Sesión</button>
                </div>
                <div class="caja__trasera-register">
                    <h3>¿Aún no tienes una cuenta?</h3>
                    <p>Regístrate para que puedas iniciar sesión</p>
                    <button id="btn__registrarse">Regístrarse</button>
                </div>
            </div>

            <!--Formulario de Login y registro-->
            <div class="contenedor__login-register">
                <!--Login-->
                <form action="assets/php/login_usuario_be.php" method="POST" class="formulario__login">
                    <h2>Iniciar Sesión</h2>
                    <input type="text" placeholder="Correo Electrónico" name="correo" required>
                    <input type="password" placeholder="Contraseña" name="contrasena" required>
                    <button>Entrar</button>
                </form>

                <!--Register-->
                <form action="assets/php/registro_usuario_be.php" method="POST" class="formulario__register">
                    <h2>Regístrarse</h2>
                    <input type="text" placeholder="Nombre completo" name="nombre_completo" required>
                    <input type="text" placeholder="Correo Electronico" name="correo" required>
                    <input type="text" placeholder="Usuario" name="usuario" required>
                    <input type="password" placeholder="Contraseña" name="contrasena" required>
                    <input type="text" placeholder="Nacionalidad" name="pais" required>
                    <button>Regístrarse</button>
                </form>
            </div>
        </div>

    <script src="assets/js/script.js"></script>
</body>
</html>