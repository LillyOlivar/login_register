<?php
session_start();
include 'conexion_be.php';

$correo = mysqli_real_escape_string($conexion, $_POST['correo']);
$contrasena = $_POST['contrasena'];

$query = "SELECT * FROM usuarios WHERE correo = ? OR usuario = ?";
$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "ss", $correo, $correo);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($usuario = mysqli_fetch_assoc($result)) {
    if (password_verify($contrasena, $usuario['contrasena'])) {
        $_SESSION['usuario'] = $usuario['usuario'];
        $_SESSION['rol'] = $usuario['rol'];
        
        if ($usuario['rol'] == 'admin') {
            header("Location: ../../admin_bienvenida.php");
        } else {
            header("Location: ../../bienvenida.php");
        }
        exit;
    }
}

echo '
<script>
    alert("Usuario no existe o contraseña incorrecta, por favor verifique los datos introducidos");
    window.location.href="../../index.php";
</script>
';
exit;