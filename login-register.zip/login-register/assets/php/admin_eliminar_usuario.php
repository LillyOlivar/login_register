<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}

include 'conexion_be.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM usuarios WHERE id = $id";

    if (mysqli_query($conexion, $query)) {
        echo "<script>alert('Usuario eliminado exitosamente'); window.location.href='../../admin_bienvenida.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar usuario: " . mysqli_error($conexion) . "'); window.location.href='../../admin_bienvenida.php';</script>";
    }
} else {
    header("Location: ../../admin_bienvenida.php");
}
?>