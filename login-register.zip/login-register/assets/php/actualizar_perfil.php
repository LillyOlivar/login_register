<?php
session_start();
include '../../conexion_be.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario'])) {
    echo json_encode(['success' => false, 'message' => 'No has iniciado sesión']);
    exit;
}

$response = ['success' => false, 'message' => ''];

try {
    $usuarioActual = $_SESSION['usuario']; // Usuario actual
    $nombre = trim($_POST['nombre_completo']);
    $usuarioNuevo = trim($_POST['usuario']); // Usuario nuevo
    $correo = trim($_POST['correo']);
    $contrasena = trim($_POST['contrasena']);
    $pais = trim($_POST['pais']);

    // Validaciones básicas
    if (empty($nombre) || empty($correo) || empty($usuarioNuevo) || empty($pais)) {
        throw new Exception("Por favor, completa todos los campos obligatorios.");
    }

    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        throw new Exception("Por favor, introduce un correo electrónico válido.");
    }

    // Preparar la consulta base
    $sql = "UPDATE usuarios SET nombre_completo = ?, correo = ?, usuario = ?, pais = ?";
    $params = [$nombre, $correo, $usuarioNuevo, $pais];
    $tipos = "ssss";

    // Si se proporcionó una nueva contraseña, incluirla en la actualización
    if (!empty($contrasena)) {
        $contrasenaHash = password_hash($contrasena, PASSWORD_BCRYPT);
        $sql .= ", contrasena = ?";
        $params[] = $contrasenaHash;
        $tipos .= "s";
    }

    $sql .= " WHERE usuario = ?";
    $params[] = $usuarioActual; // Usar el usuario actual para la cláusula WHERE
    $tipos .= "s";

    // Preparar y ejecutar la consulta
    $stmt = $conexion->prepare($sql);
    if (!$stmt) {
        throw new Exception("Error en la preparación de la consulta: " . $conexion->error);
    }
    $stmt->bind_param($tipos, ...$params);

    if ($stmt->execute()) {
        // Actualizar la sesión con el nuevo nombre de usuario
        $_SESSION['usuario'] = $usuarioNuevo;
        $response['success'] = true;
        $response['message'] = "Perfil actualizado correctamente";
    } else {
        throw new Exception("Error al actualizar el perfil: " . $stmt->error);
    }

    $stmt->close();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);

// Redirigir a la página principal después de la actualización
if ($response['success']) {
    header("Location: ../../bienvenida.php"); // Ajusta esta ruta si es necesario
    exit();
}