<?php
include 'conexion_be.php';
include 'sensor_simulator.php';

function readSensorData() {
    global $conexion;
    $query = "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1";
    $result = mysqli_query($conexion, $query);
    if ($result && mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }
    return null;
}

function saveSensorData($temperature, $humidity, $uvIntensity, $pm25, $pm10) {
    global $conexion;
    $query = "INSERT INTO sensor_readings (temperature, humidity, uvIntensity, pm25, pm10) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "ddddd", $temperature, $humidity, $uvIntensity, $pm25, $pm10);
    return mysqli_stmt_execute($stmt);
}

function getLatestSensorData() {
    $simulator = new SensorSimulator();
    $data = $simulator->getSensorData();
    saveSensorData($data['temperature'], $data['humidity'], $data['uvIntensity'], $data['pm25'], $data['pm10']);
    return $data;
}
?>