<?php
{
  $conexion = mysqli_connect("localhost", "root" , "", "login_register");
}
;