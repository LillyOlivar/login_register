<?php
include("conexion_be.php");

$nombre_completo = mysqli_real_escape_string($conexion, $_POST['nombre_completo']);
$correo = mysqli_real_escape_string($conexion, $_POST['correo']);
$usuario = mysqli_real_escape_string($conexion, $_POST['usuario']);
$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);
$pais = mysqli_real_escape_string($conexion, $_POST['pais']);
$rol = 'usuario';

$query = "INSERT INTO usuarios (nombre_completo, correo, usuario, contrasena, pais, rol) 
          VALUES ('$nombre_completo', '$correo', '$usuario', '$contrasena', '$pais', '$rol')";

$ejecutar = mysqli_query($conexion, $query);
if($ejecutar){
    echo'<script>
    alert("Usuario registrado exitosamente");
    window.location.href="../../index.php";
    </script>';
} else {
    echo 'Error al registrar el usuario: ' . mysqli_error($conexion);
}
?>