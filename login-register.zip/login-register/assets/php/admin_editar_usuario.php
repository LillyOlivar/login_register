<?php
session_start();
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../../index.php");
    exit();
}

include 'conexion_be.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM usuarios WHERE id = $id";
    $result = mysqli_query($conexion, $query);
    $usuario = mysqli_fetch_assoc($result);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $usuario = $_POST['usuario'];
    $pais = $_POST['pais'];
    $rol = $_POST['rol'];

    $query = "UPDATE usuarios SET nombre_completo='$nombre_completo', correo='$correo', 
              usuario='$usuario', pais='$pais', rol='$rol' WHERE id=$id";

    if (mysqli_query($conexion, $query)) {
        echo "<script>alert('Usuario actualizado exitosamente'); window.location.href='../../admin_bienvenida.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar usuario: " . mysqli_error($conexion) . "'); window.location.href='../../admin_bienvenida.php';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuario</title>
</head>
<body>
    <h2>Editar Usuario</h2>
    <form action="admin_editar_usuario.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $usuario['id']; ?>">
        <input type="text" name="nombre_completo" value="<?php echo $usuario['nombre_completo']; ?>" required>
        <input type="email" name="correo" value="<?php echo $usuario['correo']; ?>" required>
        <input type="text" name="usuario" value="<?php echo $usuario['usuario']; ?>" required>
        <input type="text" name="pais" value="<?php echo $usuario['pais']; ?>" required>
        <select name="rol" required>
            <option value="usuario" <?php echo ($usuario['rol'] == 'usuario') ? 'selected' : ''; ?>>Usuario</option>
            <option value="admin" <?php echo ($usuario['rol'] == 'admin') ? 'selected' : ''; ?>>Administrador</option>
        </select>
        <button type="submit">Actualizar Usuario</button>
    </form>
    <a href="../../admin_bienvenida.php">Volver al Panel de Administración</a>
</body>
</html>