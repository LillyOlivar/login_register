<?php
include 'conexion_be.php';

// Obtener parámetros de la solicitud
$timeFrame = isset($_GET['timeFrame']) ? $_GET['timeFrame'] : '1d';
$currentTime = date('Y-m-d H:i:s');

// Preparar la consulta SQL basada en el marco de tiempo
switch($timeFrame) {
    case '1h':
        $interval = "1 HOUR";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d %H:%i')";
        break;
    case '6h':
        $interval = "6 HOUR";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d %H:%i')";
        break;
    case '12h':
        $interval = "12 HOUR";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d %H:%i')";
        break;
    case '1d':
        $interval = "1 DAY";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d %H')";
        break;
    case '3d':
        $interval = "3 DAY";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d %H')";
        break;
    case '1w':
        $interval = "1 WEEK";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d')";
        break;
    case '2w':
        $interval = "2 WEEK";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d')";
        break;
    case '1m':
        $interval = "1 MONTH";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d')";
        break;
    default:
        $interval = "1 DAY";
        $groupBy = "DATE_FORMAT(timestamp, '%Y-%m-%d %H')";
}

$query = "SELECT 
    $groupBy as time,
    AVG(temperature) as temperature,
    AVG(humidity) as humidity,
    AVG(uvIntensity) as uvIntensity,
    AVG(pm25) as pm25,
    AVG(pm10) as pm10
FROM sensor_readings 
WHERE timestamp >= DATE_SUB(?, INTERVAL $interval)
GROUP BY $groupBy
ORDER BY time ASC";

$stmt = mysqli_prepare($conexion, $query);
mysqli_stmt_bind_param($stmt, "s", $currentTime);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = [
        'time' => $row['time'],
        'temperature' => round(floatval($row['temperature']), 1),
        'humidity' => round(floatval($row['humidity']), 1),
        'uvIntensity' => round(floatval($row['uvIntensity']), 2),
        'pm25' => round(floatval($row['pm25']), 1),
        'pm10' => round(floatval($row['pm10']), 1)
    ];
}

header('Content-Type: application/json');
echo json_encode($data);
?>