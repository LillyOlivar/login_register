<?php
session_start();
include 'conexion_be.php';

// Verifica si hay un usuario en sesión
if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'No hay sesión activa']);
    exit;
}

// Obtener el usuario actual de la sesión
$usuario = $_SESSION['usuario'];

// Leer y decodificar los datos enviados por el cliente
$alertas = json_decode(file_get_contents('php://input'), true);

// Validar que los datos enviados sean válidos
if (!$alertas || !is_array($alertas)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Datos inválidos recibidos']);
    exit;
}

// Inicializar un contador de errores
$errores = 0;

// Recorrer las alertas recibidas
foreach ($alertas as $alerta) {
    $mensaje = $alerta['message']; // Extraer el mensaje de la alerta

    // Preparar la consulta para insertar la alerta
    $stmt = $conexion->prepare("INSERT INTO alertas (usuario, mensaje, fecha) VALUES (?, ?, NOW())");
    $stmt->bind_param('ss', $usuario, $mensaje);

    // Ejecutar la consulta y verificar si hubo errores
    if (!$stmt->execute()) {
        $errores++;
    }

    // Cerrar el statement
    $stmt->close();
}

// Responder al cliente según el resultado
if ($errores === 0) {
    echo json_encode(['success' => true, 'message' => 'Alertas guardadas correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => "Algunas alertas no se guardaron. Errores: $errores"]);
}

// Cerrar la conexión a la base de datos
$conexion->close();
?>
