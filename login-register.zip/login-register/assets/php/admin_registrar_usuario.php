<?php
session_start();
include 'conexion_be.php';

// Función para loguear errores
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . "\n", 3, 'error_log.txt');
}

// Verificar si el usuario es admin
if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'No tienes permisos para realizar esta acción']);
    logError("Intento de acceso no autorizado: " . ($_SESSION['usuario'] ?? 'Usuario no identificado'));
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validar y escapar los datos de entrada
    $nombre_completo = mysqli_real_escape_string($conexion, $_POST['nombre_completo'] ?? '');
    $correo = mysqli_real_escape_string($conexion, $_POST['correo'] ?? '');
    $usuario = mysqli_real_escape_string($conexion, $_POST['usuario'] ?? '');
    $contrasena = $_POST['contrasena'] ?? '';
    $pais = mysqli_real_escape_string($conexion, $_POST['pais'] ?? '');
    $rol = mysqli_real_escape_string($conexion, $_POST['rol'] ?? '');

    // Verificar que todos los campos necesarios estén presentes
    if (empty($nombre_completo) || empty($correo) || empty($usuario) || empty($contrasena) || empty($pais) || empty($rol)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
        logError("Intento de registro con campos vacíos");
        exit();
    }

    // Verificar si el usuario ya existe
    $check_query = "SELECT * FROM usuarios WHERE correo = ? OR usuario = ?";
    $check_stmt = mysqli_prepare($conexion, $check_query);
    mysqli_stmt_bind_param($check_stmt, "ss", $correo, $usuario);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if(mysqli_num_rows($check_result) > 0) {
        echo json_encode(['success' => false, 'message' => 'El usuario o correo ya existe']);
        logError("Intento de registro de usuario existente: $correo o $usuario");
        exit();
    }

    // Hashear la contraseña
    $contrasena_hash = password_hash($contrasena, PASSWORD_DEFAULT);

    // Preparar la consulta de inserción
    $query = "INSERT INTO usuarios (nombre_completo, correo, usuario, contrasena, pais, rol) 
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "ssssss", $nombre_completo, $correo, $usuario, $contrasena_hash, $pais, $rol);
    
    // Ejecutar la consulta
    if(mysqli_stmt_execute($stmt)){
        $new_user = [
            'id' => mysqli_insert_id($conexion),
            'nombre_completo' => $nombre_completo,
            'correo' => $correo,
            'usuario' => $usuario,
            'pais' => $pais,
            'rol' => $rol
        ];
        echo json_encode(['success' => true, 'message' => 'Usuario registrado exitosamente', 'user' => $new_user]);
        logError("Usuario registrado exitosamente: $usuario");
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al registrar el usuario: ' . mysqli_error($conexion)]);
        logError("Error al registrar usuario: " . mysqli_error($conexion));
    }
    exit();
}

echo json_encode(['success' => false, 'message' => 'Método de solicitud no válido']);
logError("Intento de acceso con método no válido");
exit();