<?php
class SensorSimulator {
    private $temperature;
    private $humidity;
    private $uvIntensity;
    private $pm25;
    private $pm10;

    public function __construct() {
        $this->updateSensorData();
    }

    private function updateSensorData() {
        // Simulamos la lectura de los sensores con valores aleatorios
        $this->temperature = rand(20, 35);
        $this->humidity = rand(30, 80);
        $this->uvIntensity = rand(0, 15) / 10;
        $this->pm25 = rand(0, 500) / 10;
        $this->pm10 = rand(0, 1000) / 10;
    }

    public function getSensorData() {
        $this->updateSensorData(); // Actualizamos los datos cada vez que se solicitan
        return [
            'temperature' => $this->temperature,
            'humidity' => $this->humidity,
            'uvIntensity' => $this->uvIntensity,
            'pm25' => $this->pm25,
            'pm10' => $this->pm10
        ];
    }
}
?>