<?php
include 'conexion_be.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $temperature = floatval($_POST['temperature']);
    $humidity = floatval($_POST['humidity']);
    $uvIntensity = floatval($_POST['uvIntensity']);
    $pm25 = floatval($_POST['pm25']);
    $pm10 = floatval($_POST['pm10']);

    // Consulta para insertar los datos de los sensores
    $query = "INSERT INTO sensor_readings (temperature, humidity, uvIntensity, pm25, pm10) 
              VALUES (?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conexion, $query);
    mysqli_stmt_bind_param($stmt, "ddddd", $temperature, $humidity, $uvIntensity, $pm25, $pm10);
    
    if (mysqli_stmt_execute($stmt)) {
        echo json_encode(['success' => true, 'message' => 'Datos guardados correctamente']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al guardar datos']);
    }
}
?>
