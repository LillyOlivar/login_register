<?php
session_start();
include 'conexion_be.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No hay sesión activa']);
    exit;
}

// Obtener las últimas 10 alertas para el usuario actual
$usuario = $_SESSION['usuario'];
$sql = "SELECT * FROM alertas WHERE usuario = ? ORDER BY fecha DESC LIMIT 10";
$stmt = $conexion->prepare($sql);
$stmt->bind_param('s', $usuario);
$stmt->execute();
$resultado = $stmt->get_result();

$alertas = [];
while ($row = $resultado->fetch_assoc()) {
    $alertas[] = $row;
}

// Enviar las alertas al cliente
header('Content-Type: application/json');
echo json_encode($alertas);

$stmt->close();
$conexion->close();
?>
