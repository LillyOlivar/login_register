<?php
session_start();
include 'conexion_be.php';

// Verificar si hay una sesión activa
if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No hay sesión activa']);
    exit;
}

// Función para insertar alertas
function insertAlert($conexion, $usuario, $mensaje) {
    $stmt = $conexion->prepare("INSERT INTO alertas (usuario, mensaje) VALUES (?, ?)");
    $stmt->bind_param('ss', $usuario, $mensaje);
    return $stmt->execute();
}

function checkThresholds($conexion) {
    // Define los umbrales
    $thresholds = [
        'temperature' => ['max' => 30, 'min' => 10],
        'humidity' => ['max' => 80, 'min' => 20],
        'uvIntensity' => ['max' => 8],
        'pm25' => ['max' => 35],
        'pm10' => ['max' => 50]
    ];

    // Obtener últimos datos del sensor
    $sql = "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1";
    $result = $conexion->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
        $usuario = $_SESSION['usuario'];
        $alertas = [];
        
        // Verificar temperatura
        if ($data['temperature'] > $thresholds['temperature']['max']) {
            $mensaje = "¡Alerta! Temperatura alta: {$data['temperature']}°C";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }
        if ($data['temperature'] < $thresholds['temperature']['min']) {
            $mensaje = "¡Alerta! Temperatura baja: {$data['temperature']}°C";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }

        // Verificar humedad
        if ($data['humidity'] > $thresholds['humidity']['max']) {
            $mensaje = "¡Alerta! Humedad alta: {$data['humidity']}%";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }
        if ($data['humidity'] < $thresholds['humidity']['min']) {
            $mensaje = "¡Alerta! Humedad baja: {$data['humidity']}%";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }

        // Verificar UV
        if ($data['uvIntensity'] > $thresholds['uvIntensity']['max']) {
            $mensaje = "¡Alerta! Índice UV alto: {$data['uvIntensity']}";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }

        // Verificar PM2.5
        if ($data['pm25'] > $thresholds['pm25']['max']) {
            $mensaje = "¡Alerta! Nivel PM2.5 alto: {$data['pm25']} µg/m³";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }

        // Verificar PM10
        if ($data['pm10'] > $thresholds['pm10']['max']) {
            $mensaje = "¡Alerta! Nivel PM10 alto: {$data['pm10']} µg/m³";
            insertAlert($conexion, $usuario, $mensaje);
            $alertas[] = $mensaje;
        }

        // Devolver los datos y alertas
        header('Content-Type: application/json');
        echo json_encode([
            'hasAlerts' => count($alertas) > 0,
            'alerts' => $alertas,
            'sensorData' => $data
        ]);
    } else {
        header('Content-Type: application/json');
        echo json_encode([
            'hasAlerts' => false,
            'alerts' => [],
            'sensorData' => null,
            'error' => 'No hay datos de sensores disponibles'
        ]);
    }
}

// Ejecutar la verificación
checkThresholds($conexion);
?>