<?php
include 'conexion_be.php';

$query = "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1";
$result = mysqli_query($conexion, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
    echo json_encode([
        'temperature' => floatval($data['temperature']),
        'humidity' => floatval($data['humidity']),
        'uvIntensity' => floatval($data['uvIntensity']),
        'pm25' => floatval($data['pm25']),
        'pm10' => floatval($data['pm10']),
        'timestamp' => $data['timestamp']
    ]);
} else {
    echo json_encode([
        'temperature' => 0,
        'humidity' => 0,
        'uvIntensity' => 0,
        'pm25' => 0,
        'pm10' => 0,
        'timestamp' => null
    ]);
}
?>