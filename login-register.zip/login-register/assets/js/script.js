// Función para manejar notificaciones
document.addEventListener("DOMContentLoaded", function () {
  // Asegúrate de pedir permiso al cargar la página
  if (
    Notification.permission !== "granted" &&
    Notification.permission !== "denied"
  ) {
    const permisoBtn = document.createElement("button");
    permisoBtn.textContent = "Activar Notificaciones";
    permisoBtn.style.marginBottom = "10px";
    document.body.prepend(permisoBtn);

    permisoBtn.addEventListener("click", function () {
      Notification.requestPermission().then((permission) => {
        if (permission === "granted") {
          permisoBtn.remove();
          alert("Notificaciones activadas correctamente.");
        } else {
          alert("No se han activado las notificaciones.");
        }
      });
    });
  }
});

// Ejecutando funciones
document
  .getElementById("btn__iniciar-sesion")
  .addEventListener("click", iniciarSesion);
document.getElementById("btn__registrarse").addEventListener("click", register);
window.addEventListener("resize", anchoPage);

// Declarando variables
var formulario_login = document.querySelector(".formulario__login");
var formulario_register = document.querySelector(".formulario__register");
var contenedor_login_register = document.querySelector(
  ".contenedor__login-register"
);
var caja_trasera_login = document.querySelector(".caja__trasera-login");
var caja_trasera_register = document.querySelector(".caja__trasera-register");

// FUNCIONES

function anchoPage() {
  if (window.innerWidth > 850) {
    caja_trasera_register.style.display = "block";
    caja_trasera_login.style.display = "block";
  } else {
    caja_trasera_register.style.display = "block";
    caja_trasera_register.style.opacity = "1";
    caja_trasera_login.style.display = "none";
    formulario_login.style.display = "block";
    contenedor_login_register.style.left = "0px";
    formulario_register.style.display = "none";
  }
}

anchoPage();

function iniciarSesion() {
  if (window.innerWidth > 850) {
    formulario_login.style.display = "block";
    contenedor_login_register.style.left = "10px";
    formulario_register.style.display = "none";
    caja_trasera_register.style.opacity = "1";
    caja_trasera_login.style.opacity = "0";
  } else {
    formulario_login.style.display = "block";
    contenedor_login_register.style.left = "0px";
    formulario_register.style.display = "none";
    caja_trasera_register.style.display = "block";
    caja_trasera_login.style.display = "none";
  }
}

function register() {
  if (window.innerWidth > 850) {
    formulario_register.style.display = "block";
    contenedor_login_register.style.left = "410px";
    formulario_login.style.display = "none";
    caja_trasera_register.style.opacity = "0";
    caja_trasera_login.style.opacity = "1";
  } else {
    formulario_register.style.display = "block";
    contenedor_login_register.style.left = "0px";
    formulario_login.style.display = "none";
    caja_trasera_register.style.display = "none";
    caja_trasera_login.style.display = "block";
    caja_trasera_login.style.opacity = "1";
  }
}

function verEstadoSensores() {
  $("#estadoSensores").toggle();
  $.ajax({
    type: "GET",
    url: "get_sensor_data.php",
    success: function (data) {
      $("#infoSensores").html(data);
    },
  });
}

// Lógica para las alertas de sensores
const temperatureThreshold = 30; // Umbral de temperatura
const humidityThreshold = 70; // Umbral de humedad

// Función para revisar continuamente los datos de los sensores
function checkSensorThresholdsContinually() {
  // Suponiendo que obtienes los datos de los sensores de alguna fuente.
  // Reemplaza esto con la lógica para obtener datos actuales del sensor.
  fetch("get_sensor_data.php") // O cualquier otro endpoint para obtener los datos
    .then((response) => response.json())
    .then((data) => {
      const alerts = [];
      if (data.temperature > temperatureThreshold) {
        alerts.push({
          type: "temperature",
          message: `Temperatura alta: ${data.temperature}°C`,
        });
      }
      if (data.humidity > humidityThreshold) {
        alerts.push({
          type: "humidity",
          message: `Humedad alta: ${data.humidity}%`,
        });
      }
      // Agrega otras verificaciones según sea necesario.

      if (alerts.length > 0) {
        alerts.forEach((alert) => {
          new Notification("¡Alerta!", { body: alert.message });
        });
        sendAlertsToServer(alerts); // Enviar las alertas al servidor
      }
    })
    .catch((error) =>
      console.error("Error al obtener los datos de los sensores:", error)
    );
}

// Llamar a la función cada 5 segundos para verificar alertas
setInterval(checkSensorThresholdsContinually, 5000); // Verifica cada 5 segundos

// Función para enviar alertas al servidor
function sendAlertsToServer(alerts) {
  fetch("assets/php/guardar_alertas.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(alerts),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        console.log("Alertas guardadas en la base de datos.");
      } else {
        console.error("Error al guardar alertas:", data.message);
      }
    })
    .catch((error) => console.error("Error en la solicitud:", error));
}

// Lógica para mostrar las últimas 10 alertas cuando el usuario haga clic en "Ver Notificaciones"
document
  .getElementById("ver-notificaciones-btn")
  .addEventListener("click", function () {
    fetch("assets/php/get_alert.php")
      .then((response) => response.json())
      .then((alerts) => {
        if (alerts.length > 0) {
          let alertList = "<ul>";
          alerts.forEach((alert) => {
            alertList += `<li>${alert.message} - ${alert.fecha}</li>`;
          });
          alertList += "</ul>";
          document.getElementById("alert-container").innerHTML = alertList; // Muestra las alertas en el contenedor
        } else {
          document.getElementById("alert-container").innerHTML =
            "No hay alertas.";
        }
      })
      .catch((error) => console.error("Error al obtener alertas:", error));
  });
