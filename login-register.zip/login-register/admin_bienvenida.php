<?php
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['rol'] !== 'admin') {
    echo '
    <script>
    alert("Por favor debes iniciar sesión como administrador");
    window.location="index.php";
    </script>
    ';
    session_destroy();
    die();
}

include 'assets/php/conexion_be.php';

// Función para obtener todos los usuarios
function getUsuarios($conexion) {
    $query = "SELECT id, nombre_completo, correo, usuario, pais, rol FROM usuarios";
    $result = mysqli_query($conexion, $query);
    if (!$result) {
        die("Error al obtener usuarios: " . mysqli_error($conexion));
    }
    return mysqli_fetch_all($result, MYSQLI_ASSOC);
}

$usuarios = getUsuarios($conexion);

function getLatestSensorData($conexion) {
    $sql = "SELECT * FROM sensor_readings ORDER BY timestamp DESC LIMIT 1";
    $result = $conexion->query($sql);
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    return null;
}

$sensorData = getLatestSensorData($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.bundle.min.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .admin-panel {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        .admin-panel h1 {
            color: #46A2FD;
        }
        .admin-panel nav {
            margin: 20px 0;
        }
        .admin-panel nav ul {
            list-style-type: none;
            padding: 0;
        }
        .admin-panel nav ul li {
            display: inline-block;
            margin-right: 10px;
        }
        .admin-panel button {
            background-color: #46A2FD;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .admin-panel button:hover {
            background-color: #3483fa;
        }
        .section-content {
            display: none;
            margin-top: 20px;
        }
        .sensor-data {
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 10px;
        }
        .sensor-data h2 {
            color: #46A2FD;
        }
        .charts-container {
            display: flex;
            justify-content: space-between;
        }
        .chart-wrapper {
            width: 30%;
        }
    </style>
</head>
<body>
    <main>
        <div class="admin-panel">
            <h1>Bienvenido al Panel de Administración</h1>
            <p>Hola, <?php echo htmlspecialchars($_SESSION['usuario']); ?>, ¡bienvenido al panel de administración!</p>
            
            <nav>
                <ul>
                    <li><button onclick="showSection('registrar')"><i class="fas fa-user-plus"></i> Registrar Usuario</button></li>
                    <li><button onclick="showSection('usuarios')"><i class="fas fa-users"></i> Ver Usuarios</button></li>
                    <li><button onclick="showSection('sensores')"><i class="fas fa-chart-line"></i> Estado de Sensores</button></li>
                </ul>
            </nav>

            <!-- Sección de Registrar Usuario -->
            <section id="registrarSection" class="section-content">
                <h2>Registrar Nuevo Usuario</h2>
                <form id="userForm">
                    <input type="text" name="nombre_completo" placeholder="Nombre completo" required>
                    <input type="email" name="correo" placeholder="Correo electrónico" required>
                    <input type="text" name="usuario" placeholder="Nombre de usuario" required>
                    <input type="password" name="contrasena" placeholder="Contraseña" required>
                    <input type="text" name="pais" placeholder="País" required>
                    <select name="rol" required>
                        <option value="usuario">Usuario</option>
                        <option value="admin">Administrador</option>
                    </select>
                    <button type="submit">Registrar Usuario</button>
                </form>
            </section>

            <!-- Sección de Usuarios -->
            <section id="usuariosSection" class="section-content">
                <h2>Lista de Usuarios</h2>
                <?php if (empty($usuarios)): ?>
                    <p>No hay usuarios registrados.</p>
                <?php else: ?>
                    <table class="tabla-usuarios">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Usuario</th>
                                <th>País</th>
                                <th>Rol</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="userTableBody">
                            <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($usuario['id']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['nombre_completo']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['correo']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['usuario']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['pais']); ?></td>
                                <td><?php echo htmlspecialchars($usuario['rol']); ?></td>
                                <td>
                                    <a href="assets/php/admin_editar_usuario.php?id=<?php echo $usuario['id']; ?>" class="action-btn"><i class="fas fa-edit"></i></a>
                                    <a href="assets/php/admin_eliminar_usuario.php?id=<?php echo $usuario['id']; ?>" onclick="return confirm('¿Estás seguro de que quieres eliminar este usuario?')" class="action-btn"><i class="fas fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </section>

            <!-- Sección de Sensores -->
            <section id="sensoresSection" class="section-content">
                <div class="sensor-data">
                    <h2>Datos de los Sensores</h2>
                    <div class="time-selector">
                        <select id="timeRange" onchange="changeTimeRange()">
                            <option value="1">Última hora</option>
                            <option value="24">Último día</option>
                            <option value="168">Última semana</option>
                            <option value="720">Último mes</option>
                        </select>
                    </div>
                    <div class="charts-container">
                        <div class="chart-wrapper">
                            <canvas id="tempHumChart"></canvas>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="uvChart"></canvas>
                        </div>
                        <div class="chart-wrapper">
                            <canvas id="pmChart"></canvas>
                        </div>
                    </div>

                    <h3>Datos Actuales</h3>
                    <div>
                        <p>Temperatura: <span id="temperature">-</span> °C</p>
                        <p>Humedad: <span id="humidity">-</span> %</p>
                        <p>Intensidad UV: <span id="uvIntensity">-</span> mW/cm²</p>
                        <p>PM2.5: <span id="pm25">-</span> µg/m³</p>
                        <p>PM10: <span id="pm10">-</span> µg/m³</p>
                        <p>Última actualización: <span id="lastUpdate">-</span></p>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <a href="assets/php/cerrar_sesion.php" class="cerrar-sesion"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>

    <script>
        // Función para mostrar secciones
        function showSection(sectionName) {
            // Ocultar todas las secciones
            ['registrar', 'usuarios', 'sensores'].forEach(section => {
                const sectionElement = document.getElementById(section + 'Section');
                sectionElement.style.display = 'none';
            });

            // Mostrar la sección seleccionada
            const selectedSection = document.getElementById(sectionName + 'Section');
            selectedSection.style.display = 'block';

            // Si es la sección de sensores, inicializar gráficas
            if (sectionName === 'sensores') {
                if (!tempHumChart) {
                    initializeCharts();
                    updateSensorData();
                    setInterval(updateSensorData, 5000);
                }
            }
        }

        // Función para mostrar/ocultar estado de sensores
        function toggleSensorStatus() {
            var sensorData1 = document.getElementById('sensorData1');
            var sensorDataDetails = document.getElementById('sensorDataDetails');
            
            if (sensorData1.style.display === 'none' || sensorData1.style.display === '') {
                sensorData1.style.display = 'block';
                sensorDataDetails.style.display = 'block';
                // Si las gráficas no están inicializadas, inicializarlas
                if (!tempHumChart) {
                    initializeCharts();
                    updateSensorData();
                    setInterval(updateSensorData, 5000);
                }
            } else {
                sensorData1.style.display = 'none';
                sensorDataDetails.style.display = 'none';
            }
        }

        function toggleRegistrarForm() {
            var form = document.getElementById('registrarForm');
            var usuarios = document.getElementById('usuarios');
            if (form.style.display === 'none' || form.style.display === '') {
                form.style.display = 'block';
                usuarios.style.display = 'none';
            } else {
                form.style.display = 'none';
            }
        }

        function mostrarUsuarios() {
            var form = document.getElementById('registrarForm');
            var usuarios = document.getElementById('usuarios');
            form.style.display = 'none';
            usuarios.style.display = 'block';
        }

        document.getElementById('userForm').addEventListener('submit', function(e) {
            e.preventDefault();
            var formData = new FormData(this);

            fetch('assets/php/admin_registrar_usuario.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    addUserToTable(data.user);
                    this.reset();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Hubo un error al procesar la solicitud. Por favor, inténtelo de nuevo.');
            });
        });

        function addUserToTable(user) {
            var tbody = document.getElementById('userTableBody');
            var newRow = tbody.insertRow();
            newRow.innerHTML = `
                <td>${user.id}</td>
                <td>${user.nombre_completo}</td>
                <td>${user.correo}</td>
                <td>${user.usuario}</td>
                <td>${user.pais}</td>
                <td>${user.rol}</td>
                <td>
                    <a href="assets/php/admin_editar_usuario.php?id=${user.id}" class="action-btn"><i class="fas fa-edit"></i></a>
                    <a href="assets/php/admin_eliminar_usuario.php?id=${user.id}" onclick="return confirm('¿Estás seguro de que quieres eliminar este usuario?')" class="action-btn"><i class="fas fa-trash"></i></a>
                </td>
            `;
        }
    </script>
    <script>
function updateSensorData() {
    fetch('assets/php/get_sensor_data.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('temperature').textContent = data.temperature.toFixed(1);
            document.getElementById('humidity').textContent = data.humidity.toFixed(1);
            document.getElementById('uvIntensity').textContent = data.uvIntensity.toFixed(2);
            document.getElementById('pm25').textContent = data.pm25.toFixed(1);
            document.getElementById('pm10').textContent = data.pm10.toFixed(1);
            document.getElementById('lastUpdate').textContent = new Date().toLocaleString();
        })
        .catch(error => console.error('Error:', error));
}

// Actualizar los datos inmediatamente y luego cada 5 segundos
updateSensorData();
setInterval(updateSensorData, 5000);
</script>

<!-- Añadir este script al final del body -->
<script>
let tempHumChart=null, uvChart=null, pmChart=null;
let sensorData = {
    labels: [],
    temperature: [],
    humidity: [],
    uvIntensity: [],
    pm25: [],
    pm10: []
};

function initializeCharts() {
    const commonOptions = {
        responsive: true,
        animation: {
            duration: 0
        },
        scales: {
            xAxes: [{
                type: 'time',
                time: {
                    unit: 'minute',
                    displayFormats: {
                        minute: 'HH:mm'
                    }
                },
                scaleLabel: {
                    display: true,
                    labelString: 'Tiempo'
                }
            }]
        }
    };

    // Gráfica de Temperatura y Humedad
    tempHumChart = new Chart(document.getElementById('tempHumChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Temperatura (°C)',
                data: [],
                borderColor: 'rgb(255, 99, 132)',
                fill: false,
                yAxisID: 'temperature'
            }, {
                label: 'Humedad (%)',
                data: [],
                borderColor: 'rgb(54, 162, 235)',
                fill: false,
                yAxisID: 'humidity'
            }]
        },
        options: {
            ...commonOptions,
            title: {
                display: true,
                text: 'Temperatura y Humedad'
            },
            scales: {
                ...commonOptions.scales,
                yAxes: [{
                    id: 'temperature',
                    position: 'left',
                    ticks: {
                        beginAtZero: true
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Temperatura (°C)'
                    }
                }, {
                    id: 'humidity',
                    position: 'right',
                    ticks: {
                        beginAtZero: true,
                        max: 100
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'Humedad (%)'
                    }
                }]
            }
        }
    });

    // Gráfica de Intensidad UV
    uvChart = new Chart(document.getElementById('uvChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'Intensidad UV (mW/cm²)',
                data: [],
                borderColor: 'rgb(255, 206, 86)',
                fill: false
            }]
        },
        options: {
            ...commonOptions,
            title: {
                display: true,
                text: 'Intensidad UV'
            },
            scales: {
                ...commonOptions.scales,
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'mW/cm²'
                    }
                }]
            }
        }
    });

    // Gráfica de PM2.5 y PM10
    pmChart = new Chart(document.getElementById('pmChart'), {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'PM2.5 (µg/m³)',
                data: [],
                borderColor: 'rgb(75, 192, 192)',
                fill: false
            }, {
                label: 'PM10 (µg/m³)',
                data: [],
                borderColor: 'rgb(153, 102, 255)',
                fill: false
            }]
        },
        options: {
            ...commonOptions,
            title: {
                display: true,
                text: 'Material Particulado'
            },
            scales: {
                ...commonOptions.scales,
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    },
                    scaleLabel: {
                        display: true,
                        labelString: 'µg/m³'
                    }
                }]
            }
        }
    });
}

function updateCharts(newData) {
    const timestamp = new Date();
    
    sensorData.labels.push(timestamp);
    sensorData.temperature.push(newData.temperature);
    sensorData.humidity.push(newData.humidity);
    sensorData.uvIntensity.push(newData.uvIntensity);
    sensorData.pm25.push(newData.pm25);
    sensorData.pm10.push(newData.pm10);

    const timeRange = parseInt(document.getElementById('timeRange').value);
    const cutoffTime = new Date(timestamp - (timeRange * 60 * 60 * 1000));

    const keepIndex = sensorData.labels.findIndex(date => date >= cutoffTime);
    if (keepIndex > 0) {
        sensorData.labels = sensorData.labels.slice(keepIndex);
        sensorData.temperature = sensorData.temperature.slice(keepIndex);
        sensorData.humidity = sensorData.humidity.slice(keepIndex);
        sensorData.uvIntensity = sensorData.uvIntensity.slice(keepIndex);
        sensorData.pm25 = sensorData.pm25.slice(keepIndex);
        sensorData.pm10 = sensorData.pm10.slice(keepIndex);
    }

    updateChart(tempHumChart, sensorData.labels, [
        {data: sensorData.temperature},
        {data: sensorData.humidity}
    ]);
    updateChart(uvChart, sensorData.labels, [{data: sensorData.uvIntensity}]);
    updateChart(pmChart, sensorData.labels, [
        {data: sensorData.pm25},
        {data: sensorData.pm10}
    ]);

    // Actualizar valores actuales
    document.getElementById('temperature').textContent = newData.temperature.toFixed(1);
    document.getElementById('humidity').textContent = newData.humidity.toFixed(1);
    document.getElementById('uvIntensity').textContent = newData.uvIntensity.toFixed(2);
    document.getElementById('pm25').textContent = newData.pm25.toFixed(1);
    document.getElementById('pm10').textContent = newData.pm10.toFixed(1);
    document.getElementById('lastUpdate').textContent = timestamp.toLocaleString();
}

function updateChart(chart, labels, datasets) {
    chart.data.labels = labels;
    datasets.forEach((dataset, i) => {
        chart.data.datasets[i].data = dataset.data;
    });
    chart.update('none'); // 'none' desactiva la animación para actualizaciones más suaves
}

function changeTimeRange() {
    const timeRange = parseInt(document.getElementById('timeRange').value);
    const now = new Date();
    const cutoffTime = new Date(now - (timeRange * 60 * 60 * 1000));

    const keepIndex = sensorData.labels.findIndex(date => date >= cutoffTime);
    if (keepIndex > 0) {
        sensorData.labels = sensorData.labels.slice(keepIndex);
        sensorData.temperature = sensorData.temperature.slice(keepIndex);
        sensorData.humidity = sensorData.humidity.slice(keepIndex);
        sensorData.uvIntensity = sensorData.uvIntensity.slice(keepIndex);
        sensorData.pm25 = sensorData.pm25.slice(keepIndex);
        sensorData.pm10 = sensorData.pm10.slice(keepIndex);

        updateChart(tempHumChart, sensorData.labels, [
            {data: sensorData.temperature},
            {data: sensorData.humidity}
        ]);
        updateChart(uvChart, sensorData.labels, [{data: sensorData.uvIntensity}]);
        updateChart(pmChart, sensorData.labels, [
            {data: sensorData.pm25},
            {data: sensorData.pm10}
        ]);
    }
}

function updateSensorData() {
    fetch('assets/php/get_sensor_data.php')
        .then(response => response.json())
        .then(data => {
            updateCharts(data);
        })
        .catch(error => console.error('Error:', error));
}

document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    updateSensorData();
    setInterval(updateSensorData, 5000);
});
</script>
</body>

</html>